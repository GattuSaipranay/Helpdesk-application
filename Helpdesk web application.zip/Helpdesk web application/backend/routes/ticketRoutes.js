const express = require("express");
const { createTicket, getTickets } = require("../controllers/ticketController");
const router = express.Router();

router.post("/", createTicket); // Create new ticket
router.get("/", getTickets); // Get all tickets

module.exports = router;
