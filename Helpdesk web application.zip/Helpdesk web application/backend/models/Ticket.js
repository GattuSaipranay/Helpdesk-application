const mongoose = require("mongoose");

const ticketSchema = new mongoose.Schema({
  title: String,
  description: String,
  status: { type: String, default: "Active" },
  customerName: String,
  lastUpdatedOn: { type: Date, default: Date.now },
  notes: [{ body: String, date: Date }],
});

module.exports = mongoose.model("Ticket", ticketSchema);
