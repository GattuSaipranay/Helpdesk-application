import React, { useEffect, useState } from "react";
import axios from "axios";

const Dashboard = () => {
  const [stats, setStats] = useState({ tickets: 0, users: 0 });

  useEffect(() => {
    axios
      .get("/api/admin/dashboard")
      .then((response) => {
        setStats(response.data);
      })
      .catch((error) => {
        console.error("Error fetching dashboard stats", error);
      });
  }, []);

  return (
    <div>
      <h2>Admin Dashboard</h2>
      <p>Total Tickets: {stats.tickets}</p>
      <p>Total Users: {stats.users}</p>
    </div>
  );
};

export default Dashboard;
