import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import TicketList from "./components/TicketList";
import TicketForm from "./components/TicketForm";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<TicketList />} />
        <Route path="/new-ticket" element={<TicketForm />} />
        <Route path="/login" element={<Login />} />
        <Route path="/admin/dashboard" element={<Dashboard />} />
      </Routes>
    </Router>
  );
}

export default App;
